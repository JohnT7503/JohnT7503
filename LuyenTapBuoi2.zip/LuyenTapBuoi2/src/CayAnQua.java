/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author home
 */
public class CayAnQua extends ThucVat {

    private int muaRaQua;

    public CayAnQua() {
    }

    public CayAnQua(int muaRaQua, String maTV, String ten, String khuVuc, int canNang) {
        super(maTV, ten, khuVuc, canNang);
        this.muaRaQua = muaRaQua;
    }

    public int getMuaRaQua() {
        return muaRaQua;
    }

    public void setMuaRaQua(int muaRaQua) {
        this.muaRaQua = muaRaQua;
    }

    public String getMuaRaQua(int muaRaQua) {
        String getMua = "";
        if (muaRaQua == 1) {
            return getMua = "Xuan";
        } else if (muaRaQua == 2) {
            return getMua = "Ha";
        } else if (muaRaQua == 3) {
            return getMua = "Thu";
        } else if (muaRaQua == 4) {
            return getMua = "Dong";
        } else {
            return getMua = "Khong co mua nao";
        }
    }

    public void display() {
        System.out.println("ThucVat = {MaTV: " + super.getMaTV() + ", Ten: " + super.getTen() + ", Khu Vuc: " + super.getKhuVuc() + ", Can nang: " + super.getCanNang() + ", Mua ra qua: " + getMuaRaQua(muaRaQua) + "}");
    }
}
