
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author home
 */
public class ThucVatService implements IThucVat {

    public ThucVat inputThucVat() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ma tv: ");
        String maTV = sc.nextLine();
        System.out.println("Nhap ten: ");
        String ten = sc.nextLine();
        System.out.println("Nhap khu vuc");
        String khuVuc = sc.nextLine();
        System.out.println("Nhap can nang: ");
        int canNang = Integer.valueOf(sc.nextLine());
        ThucVat tv = new ThucVat(maTV, ten, khuVuc, canNang);
        return tv;
    }

    public ArrayList<ThucVat> timThucVatTheoKhoang(ArrayList<ThucVat> listTree, int min, int max) {
        ArrayList<ThucVat> listFound = new ArrayList<>();
        for (ThucVat tv : listTree) {
            if (tv.getCanNang() >= min && tv.getCanNang() <= max) {
                listFound.add(tv);
            }
        }
        return listFound;
    }
}
