/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author home
 */
public class SinhVien extends Nguoi {

    private String maSV;
    private double diem;

    public SinhVien() {
    }

    public SinhVien(String maSV, double diem, String ten, int tuoi, String diaChi) {
        super(ten, tuoi, diaChi);
        this.maSV = maSV;
        this.diem = diem;
    }

    public String getMaSV() {
        return maSV;
    }

    public void setMaSV(String maSV) {
        this.maSV = maSV;
    }

    public double getDiem() {
        return diem;
    }

    public void setDiem(double diem) {
        this.diem = diem;
    }

    public void display() {
        System.out.println("Nguoi ={Ten: " + super.getTen() + ", Tuoi: " + super.getTuoi() + ", Dia chi: " + super.getDiaChi() + ", MaSV: " + this.maSV + ", Diem: " + this.diem + "}");
    }
}
