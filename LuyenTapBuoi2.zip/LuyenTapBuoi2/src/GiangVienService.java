
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author home
 */
public class GiangVienService implements ICommon{
    public GiangVien inputGiangVien() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ten: ");
        String ten = sc.nextLine();
        System.out.println("Nhap tuoi: ");
        int tuoi = Integer.valueOf(sc.nextLine());
        System.out.println("Nhap dia chi: ");
        String diaChi = sc.nextLine();
        System.out.println("Nhap bac: ");
        int bac = Integer.valueOf(sc.nextLine());
        GiangVien gv = new GiangVien(bac, ten, tuoi, diaChi);
        return gv;
    }

    @Override
    public Nguoi inputNguoi() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
