
import java.util.ArrayList;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author home
 */
public class Main {

    public static void main(String[] args) {
        Main();
    }

    public static void Main() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("1. Bai 1");
            System.out.println("2. Bai 2");
            System.out.println("0. Thoat");
            int luaChon = Integer.valueOf(sc.nextLine());
            switch (luaChon) {
                case 1 -> {
                    Bai1();
                }
                case 2 -> {
                    Bai2();
                }
                case 0 -> {
                    System.exit(0);
                }
            }
        }
    }

    public static void Bai1() {
        Scanner sc = new Scanner(System.in);
        NguoiService nguoiService = new NguoiService();
        SinhVienService sinhVienService = new SinhVienService();
        GiangVienService giangVienService = new GiangVienService();
        ArrayList<Nguoi> listHuman = new ArrayList<>();
        while (true) {
            System.out.println("1. Nhập người");
            System.out.println("2. Nhập sinh viên");
            System.out.println("3. Nhập giảng viên");
            System.out.println("0. Thoat");
            System.out.print("Lựa chọn: ");
            int luaChon = Integer.valueOf(sc.nextLine());
            switch (luaChon) {
                case 1 -> {
                    Nguoi newNguoi = nguoiService.inputNguoi();
                    listHuman.add(newNguoi);
                    newNguoi.display();
                }
                case 2 -> {
                    Nguoi newSinhVien = sinhVienService.inputSinhVien();
                    listHuman.add(newSinhVien);
                    newSinhVien.display();
                }
                case 3 -> {
                    Nguoi newGiangVien = giangVienService.inputGiangVien();
                    listHuman.add(newGiangVien);
                    newGiangVien.display();
                }
                case 0 -> {
                    Main();
                }
            }
            System.out.println("Nhap tiep khon (Y/N)");
            String tiepTuc = sc.nextLine();
            if (tiepTuc.equalsIgnoreCase("N")) {
                break;
            }
        }
    }

    public static void Bai2() {
        Scanner sc = new Scanner(System.in);
        ArrayList<ThucVat> listTree = new ArrayList<>();
        ThucVatService thucVatService = new ThucVatService();
        CayAnQuaService cayAnQuaService = new CayAnQuaService();
        while (true) {
            System.out.println("1. Them thuc vat");
            System.out.println("2. Hien thi danh sach thuc vat");
            System.out.println("3. Tim thuc vat trong khoang can nang");
            System.out.println("4. Ke thua");
            System.out.println("0. Thoat");
            int luaChon = Integer.valueOf(sc.nextLine());
            switch (luaChon) {
                case 1 -> {
                    while (true) {
                        ThucVat newThucVat = thucVatService.inputThucVat();
                        listTree.add(newThucVat);
                        System.out.println("Nhap tiep khong? (Y/N)");
                        String tiepTuc = sc.nextLine();
                        if (tiepTuc.equalsIgnoreCase("N")) {
                            break;
                        }
                    }
                }
                case 2 -> {
                    listTree.forEach(s -> s.display());
                }
                case 3 -> {
                    System.out.println("Nhap min: ");
                    int min = Integer.valueOf(sc.nextLine());
                    System.out.println("Nhap max: ");
                    int max = Integer.valueOf(sc.nextLine());
                    ArrayList<ThucVat> listFound = thucVatService.timThucVatTheoKhoang(listTree, min, max);
                    if (listFound.isEmpty()) {
                        System.out.println("Khong tim thay thuc vat nao");
                    } else {
                        listFound.forEach(s -> s.display());
                    }
                }
                case 4 -> {
                    ThucVat newCayAnQua = cayAnQuaService.inputCayAnQua();
                    listTree.add(newCayAnQua);
                    newCayAnQua.display();
                }
                case 0 -> {
                    Main();
                }
            }
        }
    }
}
