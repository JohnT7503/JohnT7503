
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author home
 */
public class CayAnQuaService implements IThucVat {

    public CayAnQua inputCayAnQua() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhap ma tv: ");
        String maTV = sc.nextLine();
        System.out.println("Nhap ten: ");
        String ten = sc.nextLine();
        System.out.println("Nhap khu vuc");
        String khuVuc = sc.nextLine();
        System.out.println("Nhap can nang: ");
        int canNang = Integer.valueOf(sc.nextLine());
        System.out.println("Nhap mua ra qua: ");
        int muaRaQua = Integer.valueOf(sc.nextLine());
        CayAnQua cayAnQua = new CayAnQua();

        cayAnQua.setMaTV(maTV);
        cayAnQua.setTen(ten);
        cayAnQua.setKhuVuc(khuVuc);
        cayAnQua.setCanNang(canNang);
        cayAnQua.setMuaRaQua(muaRaQua);
        return cayAnQua;
    }

    @Override
    public ThucVat inputThucVat() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
